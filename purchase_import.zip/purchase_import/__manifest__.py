{
    'name': 'Purchase Import',
    'version': '18.0.1.0.0',
    'category': 'Purchase',
    'summary': 'Purchase Import Management',
    'description': """
        Purchase Import Module
        ======================

        This module provides import management functionality for foreign purchase orders.

        Features:
        ---------
        * Import order creation from foreign purchase orders
        * Progressive import tracking
        * Import history management
        * Wizard-based import process

        """,
    'author': 'Your Company Name',
    'website': 'https://www.yourcompany.com',
    'license': 'LGPL-3',
    'depends': [
        'base',
        'purchase',
        'purchase_edit'
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/purchase_import_views.xml',
        'views/purchase_import_config_views.xml',
        'data/sequence_data.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}