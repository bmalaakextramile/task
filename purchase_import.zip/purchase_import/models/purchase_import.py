from odoo import models, fields, api


class ImportHistory(models.Model):
    _name = 'import.history'
    _description = 'Purchase Import'

    name = fields.Char(
        string='Name',
        required=True,
        copy=False,
        readonly=True,
        index=True,
        default=lambda self: self.env['ir.sequence'].next_by_code('import.history') or 'New'
    )

    shipping_type = fields.Selection([
        ('air_freight', 'Air Freight'),
        ('sea_freight', 'Sea Freight'),
        ('land_shipping', 'Land Shipping')
    ], string='Shipping Type', required=True)

    # Many2one field for Shipping Company (Vendors only)
    shipping_company = fields.Many2one(
        'res.partner',
        string='Shipping Company',
        domain=[('supplier_rank', '>', 0)],  # Only vendors/suppliers
        required=True,
        help='Select shipping company from vendors'
    )

    # Many2one fields pointing to purchase.import.config model
    shipping_port = fields.Many2one(
        'purchase.import.config',
        string='Shipping Port',
        required=True,
        help='Select shipping port from configured ports'
    )

    arrival_port = fields.Many2one(
        'purchase.import.config',
        string='Arrival Port',
        required=True,
        help='Select arrival port from configured ports'
    )

    expected_shipping_date = fields.Date(
        string='Expected Shipping Date',
        help='Expected date when goods will be shipped'
    )

    actual_shipping_date = fields.Date(
        string='Actual Shipping Date',
        help='Actual date when goods were shipped'
    )

    # New fields
    expected_arrival_date = fields.Date(
        string='Expected Arrival Date',
        help='Expected date when goods will arrive'
    )

    incoterm = fields.Many2one(
        'account.incoterms',
        string='Incoterm',
        help='International Commercial Terms'
    )

    shipping_weight = fields.Float(
        string='Shipping Weight',
        digits=(16, 3),
        help='Total weight of the shipment'
    )

    shipping_weight_uom = fields.Many2one(
        'uom.uom',
        string='Weight Unit of Measure',
        domain="[('category_id.name', '=', 'Weight')]",
        help='Unit of measure for shipping weight'
    )

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('import.history') or 'New'
        return super(ImportHistory, self).create(vals)

    @api.onchange('shipping_company')
    def _onchange_shipping_company(self):
        """Optional: Add logic when shipping company changes"""
        if self.shipping_company:
            # يمكنك إضافة منطق إضافي هنا إذا لزم الأمر
            pass

    @api.onchange('shipping_type')
    def _onchange_shipping_type(self):
        """Clear port selections when shipping type changes"""
        if self.shipping_type:
            self.shipping_port = False
            self.arrival_port = False

    @api.onchange('expected_shipping_date')
    def _onchange_expected_shipping_date(self):
        """Automatically set expected arrival date based on shipping date and type"""
        if self.expected_shipping_date and self.shipping_type:
            # Add estimated days based on shipping type
            days_to_add = 0
            if self.shipping_type == 'air_freight':
                days_to_add = 3  # Air freight typically takes 1-3 days
            elif self.shipping_type == 'sea_freight':
                days_to_add = 30  # Sea freight can take 15-45 days
            elif self.shipping_type == 'land_shipping':
                days_to_add = 7  # Land shipping varies but average 3-10 days

            if days_to_add > 0:
                from datetime import timedelta
                self.expected_arrival_date = self.expected_shipping_date + timedelta(days=days_to_add)