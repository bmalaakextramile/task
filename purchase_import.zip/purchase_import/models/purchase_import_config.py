from odoo import models, fields, api


class PurchaseImportConfig(models.Model):
    _name = 'purchase.import.config'
    _description = 'Purchase Import Configuration'
    _rec_name = 'shipping_port'

    shipping_port = fields.Char(
        string='Shipping Port',
        required=True,
        help="Port where goods are shipped from"
    )

    def name_get(self):
        result = []
        for record in self:
            result.append((record.id, record.shipping_port))
        return result