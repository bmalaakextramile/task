{
    'name': 'Purchase Edit',
    'version': '18.0.1.0.0',
    'category': 'Purchase',
    'summary': 'Purchase Order Editing Enhancements',
    'description': """
        Purchase Order Edit Module
        ==========================

        This module provides enhanced functionality for editing purchase orders.

        Features:
        ---------
        * Enhanced purchase order editing capabilities
        * Custom views for purchase orders
        * Extended purchase order functionality

        """,
    'author': 'Your Company Name',
    'website': 'https://www.yourcompany.com',
    'license': 'LGPL-3',
    'depends': [
        'base',
        'purchase',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/purchase_order_views.xml',
        'views/import_order_wizard_views.xml',
         'views/import_order_wizard_line_views.xml',
    ],

    'installable': True,
    'auto_install': False,
    'application': False,

}