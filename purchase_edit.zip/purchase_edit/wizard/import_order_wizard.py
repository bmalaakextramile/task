from odoo import models, fields, api
from odoo.exceptions import UserError


class ImportOrderWizard(models.TransientModel):
    _name = 'import.order.wizard'
    _description = 'Import Order Wizard'

    purchase_order_id = fields.Many2one('purchase.order', string='Purchase Order', readonly=True)
    import_line_ids = fields.One2many('import.order.wizard.line', 'wizard_id', string='Import Lines')

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)

        purchase_order_id = self.env.context.get('default_purchase_order_id')
        if purchase_order_id and 'import_line_ids' not in res:
            purchase_order = self.env['purchase.order'].browse(purchase_order_id)

            import_lines = []
            for line in purchase_order.order_line:
                import_lines.append((0, 0, {
                    'product_id': line.product_id.id,
                    'product_name': line.product_id.name,
                    'quantity': line.product_qty,  # Original Qty (للعرض)
                    'original_quantity': line.product_qty,  # Original Quantity (للحسابات)
                    'imported_quantity': 0.0,  # Imported Qty
                    'requested_quantity': 0.0,  # Requested Qty
                    'uom_id': line.product_uom.id,
                }))

            res['import_line_ids'] = import_lines

        return res

    def action_create_import(self):
        # التحقق من البيانات
        for line in self.import_line_ids:
            if line.requested_quantity <= 0:
                raise UserError(
                    f"Requested quantity for product {line.product_name} must be greater than zero"
                )

            available_qty = line.original_quantity - line.imported_quantity
            if line.requested_quantity > available_qty:
                raise UserError(
                    f"Requested quantity for product {line.product_name} exceeds available quantity ({available_qty})"
                )

        # هنا يمكن إضافة منطق إنشاء الاستيراد
        # مثل إنشاء stock picking أو تحديث الكميات

        return {'type': 'ir.actions.act_window_close'}


class ImportOrderWizardLine(models.TransientModel):
    _name = 'import.order.wizard.line'
    _description = 'Import Order Wizard Line'

    wizard_id = fields.Many2one('import.order.wizard', string='Wizard', ondelete='cascade')
    product_id = fields.Many2one('product.product', string='Product')
    product_name = fields.Char(string='Product Name', readonly=True)
    quantity = fields.Float(string='Original Qty', readonly=True)
    original_quantity = fields.Float(string='Original Quantity', readonly=True)
    imported_quantity = fields.Float(string='Imported Qty', readonly=True, default=0.0)
    requested_quantity = fields.Float(string='Requested Qty', required=True, default=0.0)
    uom_id = fields.Many2one('uom.uom', string='UoM', readonly=True)

    @api.onchange('product_id')
    def _onchange_product_id(self):
        if self.product_id:
            self.product_name = self.product_id.name