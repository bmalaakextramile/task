from odoo import models, fields, api
from odoo.exceptions import UserError


class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    purchase_type = fields.Selection(
        [('local', 'Local'), ('foreign', 'Foreign')],
        string="Purchase Type",
        default='local',
        required=True
    )

    def action_create_import_order(self):
        # التحققات الأساسية
        if not self.order_line:
            raise UserError("No products found in this purchase order")

        if self.state not in ['purchase', 'done']:
            raise UserError("You can only create import orders for confirmed purchase orders")

        return {
            'name': 'Create Import Order',
            'type': 'ir.actions.act_window',
            'res_model': 'import.order.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_purchase_order_id': self.id,
            }
        }